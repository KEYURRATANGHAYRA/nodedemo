#!/usr/bin/env bash
cd ~/node
forever stop app.js
