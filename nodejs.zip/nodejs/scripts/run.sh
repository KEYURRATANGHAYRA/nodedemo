#!/usr/bin/env bash

cd ~/node
forever start app.js
