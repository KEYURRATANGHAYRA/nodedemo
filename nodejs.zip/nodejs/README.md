node-app
========

Simple NodeJS application for testing purposes

You can use it as you want
